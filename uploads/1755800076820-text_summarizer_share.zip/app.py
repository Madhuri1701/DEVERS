from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize,sent_tokenize

import nltk
nltk.download('stopwords')
nltk.download('punkt')
nltk.download('punkt_tab')

text =("Please enter your text to summarize")

stopWords = set(stopwords.words("english"))
print(stopWords)

words = word_tokenize(text)
print(words)

freqTable = dict()

freqTable = dict()
for word in words:
  word = word.lower()
  if word in stopWords:
    continue
  # The following lines were incorrectly indented under the continue statement
  if word in freqTable:
    freqTable[word] += 1
  else:
    freqTable[word] = 1

print(freqTable)

sentences = sent_tokenize(text)
print(sentences)

sentences[0]

def getsentenceValue():
  sentenceValue = dict()
  for sentence in sentences:
    for word, freq in freqTable.items():
      if word in sentence.lower():
         if sentence in sentenceValue:
            sentenceValue[sentence] += freq
         else:
          sentenceValue[sentence] = freq
  return sentenceValue
  print(sentenceValue)

sentenceValue = getsentenceValue()
print(sentenceValue)

def getsumValues():
  sumValues = 0
  for sentence in sentenceValue:
    sumValues += sentenceValue[sentence]

  average = int(sumValues / len(sentenceValue))
  return average

average = getsumValues()
print(average)

summary = ''
for sentence in sentences:
  if (sentence in sentenceValue) and (sentenceValue[sentence] > (2.6  * average)):
      summary += " " + sentence
print(summary)